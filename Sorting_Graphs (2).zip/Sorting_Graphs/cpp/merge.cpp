// Requires gnuplot to be installed for graph generation:
//   sudo apt install gnuplot
#include <bits/stdc++.h>
#include <chrono>
using namespace std;
using namespace std::chrono;

void merge(int a[], int low, int mid, int high){
    int temp[100005];
    int i=low, j=mid+1, k=low;
    while(i<=mid && j<=high){
        if(a[i]<=a[j]) temp[k++]=a[i++];
        else temp[k++]=a[j++];
    }
    while(i<=mid) temp[k++]=a[i++];
    while(j<=high) temp[k++]=a[j++];
    for(i=low;i<=high;i++) a[i]=temp[i];
}

void mergeSort(int a[], int low, int high){
    if(low>=high) return;
    int mid=(low+high)/2;
    mergeSort(a,low,mid);
    mergeSort(a,mid+1,high);
    merge(a,low,mid,high);
}

void genRandom(int a[], int n){
    for(int i=0;i<n;i++) a[i]=rand()%100000;
}

void genAscending(int a[], int n){
    for(int i=0;i<n;i++) a[i]=i;
}

void genDescending(int a[], int n){
    for(int i=0;i<n;i++) a[i]=n-i;
}

void genPartial(int a[], int n){
    genAscending(a,n);
    int swaps=n/10+1;
    for(int i=0;i<swaps;i++){
        int x=rand()%n, y=rand()%n;
        int t=a[x]; a[x]=a[y]; a[y]=t;
    }
}

void genMissing(int a[], int n){
    int val=0;
    for(int i=0;i<n;i++){
        a[i]=val;
        val+=(rand()%3)+1;
    }
    for(int i=n-1;i>0;i--){
        int j=rand()%(i+1);
        int t=a[i]; a[i]=a[j]; a[j]=t;
    }
}

void genDuplicates(int a[], int n){
    for(int i=0;i<n;i++) a[i]=rand()%10;
}

void copyArray(int source[], int destination[], int n){
    for(int i=0;i<n;i++) destination[i]=source[i];
}

// ---------------- Benchmark ----------------
double timeSort(int original[], int n){
    int *a = new int[n];
    copyArray(original, a, n);
    auto start = high_resolution_clock::now();
    mergeSort(a, 0, n-1);
    auto stop = high_resolution_clock::now();
    double seconds = duration_cast<microseconds>(stop-start).count() / 1e6;
    delete[] a;
    return seconds;
}

// ---------------- Graph Generation (via gnuplot) ----------------
void drawChart(const string &title, const string &filename, vector<int> &sizes,
               vector<string> &caseNames, vector<vector<double>> &results){
    string dataFile = "chart_data_tmp.dat";
    ofstream out(dataFile);
    out << "# N";
    for(auto &name : caseNames) out << " \"" << name << "\"";
    out << "\n";
    for(size_t s=0;s<sizes.size();s++){
        out << sizes[s];
        for(size_t c=0;c<caseNames.size();c++) out << " " << results[c][s];
        out << "\n";
    }
    out.close();

    string scriptFile = "chart_script_tmp.gp";
    ofstream gp(scriptFile);
    gp << "set terminal pngcairo size 1000,650 enhanced font 'Sans,11'\n";
    gp << "set output '" << filename << "'\n";
    gp << "set title '" << title << "' font 'Sans,16'\n";
    gp << "set xlabel 'Input Size (N)'\n";
    gp << "set ylabel 'Time (seconds)'\n";
    gp << "set grid\n";
    gp << "set key outside right\n";
    gp << "set datafile missing 'NaN'\n";
    string colors[6] = {"#1f77b4","#ff7f0e","#2ca02c","#d62728","#9467bd","#8c564b"};
    gp << "plot ";
    for(size_t c=0;c<caseNames.size();c++){
        gp << "'" << dataFile << "' using 1:" << (c+2)
           << " with linespoints lw 2 pt 7 ps 1.2 lc rgb '" << colors[c%6]
           << "' title '" << caseNames[c] << "'";
        if(c+1<caseNames.size()) gp << ", ";
    }
    gp << "\n";
    gp.close();

    string cmd = "gnuplot " + scriptFile;
    int ret = system(cmd.c_str());
    if(ret==0) cout << "Graph saved as " << filename << "\n";
    else cout << "Warning: gnuplot failed (is it installed?). Data written to " << dataFile << "\n";
}

int main(){
    srand(time(0));

    vector<int> sizes = {100, 1000, 10000, 100000};
    vector<string> caseNames = {"Random","Ascending","Descending","Partially Ordered","Missing Numbers","Duplicates"};
    vector<vector<double>> results(6, vector<double>(sizes.size()));

    for(size_t s=0; s<sizes.size(); s++){
        int n = sizes[s];
        cout << "\n===== ARRAY SIZE = " << n << " =====\n";

        int *r=new int[n], *asc=new int[n], *des=new int[n], *par=new int[n], *mis=new int[n], *dup=new int[n];
        genRandom(r,n); genAscending(asc,n); genDescending(des,n);
        genPartial(par,n); genMissing(mis,n); genDuplicates(dup,n);
        int *arrays[6] = {r,asc,des,par,mis,dup};

        for(int c=0;c<6;c++){
            double t = timeSort(arrays[c], n);
            results[c][s] = t;
            cout << left << setw(20) << caseNames[c]
                 << " | Size = " << setw(6) << n
                 << " | Time = " << fixed << setprecision(6) << t << " sec\n";
        }

        delete[] r; delete[] asc; delete[] des; delete[] par; delete[] mis; delete[] dup;
    }

    cout << "\n" << string(86,'=') << "\n";
    cout << "MERGE SORT - EXECUTION TIME TABLE (seconds)\n";
    cout << string(86,'=') << "\n";
    cout << left << setw(20) << "Test Case";
    for(int n: sizes) cout << "N=" << left << setw(10) << n;
    cout << "\n" << string(86,'-') << "\n";
    for(int c=0;c<6;c++){
        cout << left << setw(20) << caseNames[c];
        for(size_t s=0;s<sizes.size();s++) cout << left << setw(12) << fixed << setprecision(6) << results[c][s];
        cout << "\n";
    }
    cout << string(86,'=') << "\n";

    drawChart("Merge Sort Performance", "Merge_Performance.png", sizes, caseNames, results);

    return 0;
}
