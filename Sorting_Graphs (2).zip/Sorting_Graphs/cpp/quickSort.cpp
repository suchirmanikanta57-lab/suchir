// Requires gnuplot to be installed for graph generation:
//   sudo apt install gnuplot
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <string>
#include <fstream>
#include <iomanip>
#include <vector>

using namespace std;
using namespace std::chrono;

// Random Array
void randomArray(int arr[], int n)
{
    for(int i = 0; i < n; i++)
        arr[i] = rand() % (n * 10);
}

// Ascending Array
void ascendingArray(int arr[], int n)
{
    for(int i = 0; i < n; i++)
        arr[i] = i + 1;
}

// Descending Array
void descendingArray(int arr[], int n)
{
    for(int i = 0; i < n; i++)
        arr[i] = n - i;
}

// Partially Sorted Array
void partiallySortedArray(int arr[], int n)
{
    ascendingArray(arr, n);

    for(int i = 0; i < n / 10; i++)
    {
        int a = rand() % n;
        int b = rand() % n;

        int temp = arr[a];
        arr[a] = arr[b];
        arr[b] = temp;
    }
}

// Missing Numbers Array (values have gaps, then shuffled)
void missingNumbersArray(int arr[], int n)
{
    int val = 0;
    for(int i = 0; i < n; i++)
    {
        arr[i] = val;
        val += (rand() % 3) + 1;
    }

    for(int i = n - 1; i > 0; i--)
    {
        int j = rand() % (i + 1);
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}

// Duplicate Array
void duplicateArray(int arr[], int n)
{
    for(int i = 0; i < n; i++)
        arr[i] = rand() % (n / 10 + 1);
}

// Copy Array
void copyArray(int source[], int destination[], int n)
{
    for(int i = 0; i < n; i++)
        destination[i] = source[i];
}

// Partition Function
int partition(int arr[], int low, int high)
{
    int pivot = arr[high];
    int i = low - 1;

    for(int j = low; j < high; j++)
    {
        if(arr[j] < pivot)
        {
            i++;

            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }

    int temp = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = temp;

    return i + 1;
}

// Quick Sort
void quickSort(int arr[], int low, int high)
{
    if(low < high)
    {
        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Measure Quick Sort Time
double testQuickSort(string caseName, int original[], int n)
{
    int *arr = new int[n];

    copyArray(original, arr, n);

    auto start = high_resolution_clock::now();

    quickSort(arr, 0, n - 1);

    auto stop = high_resolution_clock::now();

    auto duration = duration_cast<microseconds>(stop - start);

    cout << caseName
         << " | Size = " << n
         << " | Time = "
         << duration.count()
         << " microseconds"
         << endl;

    delete[] arr;
    return duration.count() / 1e6;
}

// ---------------- Graph Generation (via gnuplot) ----------------
void drawChart(const string &title, const string &filename, vector<int> &sizes,
               vector<string> &caseNames, vector<vector<double>> &results){
    string dataFile = "chart_data_tmp.dat";
    ofstream out(dataFile);
    out << "# N";
    for(auto &name : caseNames) out << " \"" << name << "\"";
    out << "\n";
    for(size_t s=0;s<sizes.size();s++){
        out << sizes[s];
        for(size_t c=0;c<caseNames.size();c++) out << " " << results[c][s];
        out << "\n";
    }
    out.close();

    string scriptFile = "chart_script_tmp.gp";
    ofstream gp(scriptFile);
    gp << "set terminal pngcairo size 1000,650 enhanced font 'Sans,11'\n";
    gp << "set output '" << filename << "'\n";
    gp << "set title '" << title << "' font 'Sans,16'\n";
    gp << "set xlabel 'Input Size (N)'\n";
    gp << "set ylabel 'Time (seconds)'\n";
    gp << "set grid\n";
    gp << "set key outside right\n";
    string colors[6] = {"#1f77b4","#ff7f0e","#2ca02c","#d62728","#9467bd","#8c564b"};
    gp << "plot ";
    for(size_t c=0;c<caseNames.size();c++){
        gp << "'" << dataFile << "' using 1:" << (c+2)
           << " with linespoints lw 2 pt 7 ps 1.2 lc rgb '" << colors[c%6]
           << "' title '" << caseNames[c] << "'";
        if(c+1<caseNames.size()) gp << ", ";
    }
    gp << "\n";
    gp.close();

    string cmd = "gnuplot " + scriptFile;
    int ret = system(cmd.c_str());
    if(ret==0) cout << "Graph saved as " << filename << "\n";
    else cout << "Warning: gnuplot failed (is it installed?). Data written to " << dataFile << "\n";
}

int main()
{
    srand(time(0));

    vector<int> sizes = {100, 1000, 10000, 100000};
    vector<string> caseNames = {"Random","Ascending","Descending","Partially Ordered","Missing Numbers","Duplicates"};
    vector<vector<double>> results(6, vector<double>(sizes.size()));

    for(size_t s = 0; s < sizes.size(); s++)
    {
        int n = sizes[s];

        int *random = new int[n];
        int *ascending = new int[n];
        int *descending = new int[n];
        int *partial = new int[n];
        int *missing = new int[n];
        int *duplicate = new int[n];

        randomArray(random, n);
        ascendingArray(ascending, n);
        descendingArray(descending, n);
        partiallySortedArray(partial, n);
        missingNumbersArray(missing, n);
        duplicateArray(duplicate, n);

        cout << "\n=====================================\n";
        cout << "ARRAY SIZE = " << n << endl;
        cout << "=====================================\n";

        results[0][s] = testQuickSort("Random", random, n);
        results[1][s] = testQuickSort("Ascending", ascending, n);
        results[2][s] = testQuickSort("Descending", descending, n);
        results[3][s] = testQuickSort("Partially Sorted", partial, n);
        results[4][s] = testQuickSort("Missing Numbers", missing, n);
        results[5][s] = testQuickSort("Duplicates", duplicate, n);

        delete[] random;
        delete[] ascending;
        delete[] descending;
        delete[] partial;
        delete[] missing;
        delete[] duplicate;
    }

    cout << "\n" << string(86,'=') << "\n";
    cout << "QUICK SORT - EXECUTION TIME TABLE (seconds)\n";
    cout << string(86,'=') << "\n";
    cout << left << setw(20) << "Test Case";
    for(int n: sizes) cout << "N=" << left << setw(10) << n;
    cout << "\n" << string(86,'-') << "\n";
    for(int c=0;c<6;c++){
        cout << left << setw(20) << caseNames[c];
        for(size_t s=0;s<sizes.size();s++) cout << left << setw(12) << fixed << setprecision(6) << results[c][s];
        cout << "\n";
    }
    cout << string(86,'=') << "\n";

    drawChart("Quick Sort Performance", "Quick_Performance.png", sizes, caseNames, results);

    return 0;
}