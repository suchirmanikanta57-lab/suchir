import java.util.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class MergeSort {

    static void merge(int a[], int low, int mid, int high){
        int temp[]=new int[high-low+1];
        int i=low,j=mid+1,k=0;
        while(i<=mid && j<=high){
            if(a[i]<=a[j]) temp[k++]=a[i++];
            else temp[k++]=a[j++];
        }
        while(i<=mid) temp[k++]=a[i++];
        while(j<=high) temp[k++]=a[j++];
        for(i=0;i<temp.length;i++) a[low+i]=temp[i];
    }

    static void mergeSort(int a[], int low, int high){
        if(low>=high) return;
        int mid=(low+high)/2;
        mergeSort(a,low,mid);
        mergeSort(a,mid+1,high);
        merge(a,low,mid,high);
    }

    static Random rnd=new Random();

    static void genRandom(int a[], int n){
        for(int i=0;i<n;i++) a[i]=rnd.nextInt(100000);
    }

    static void genAscending(int a[], int n){
        for(int i=0;i<n;i++) a[i]=i;
    }

    static void genDescending(int a[], int n){
        for(int i=0;i<n;i++) a[i]=n-i;
    }

    static void genPartial(int a[], int n){
        genAscending(a,n);
        int swaps=n/10+1;
        for(int i=0;i<swaps;i++){
            int x=rnd.nextInt(n), y=rnd.nextInt(n);
            int t=a[x]; a[x]=a[y]; a[y]=t;
        }
    }

    static void genMissing(int a[], int n){
        int val=0;
        for(int i=0;i<n;i++){
            a[i]=val;
            val+=rnd.nextInt(3)+1;
        }
        for(int i=n-1;i>0;i--){
            int j=rnd.nextInt(i+1);
            int t=a[i]; a[i]=a[j]; a[j]=t;
        }
    }

    static void genDuplicates(int a[], int n){
        for(int i=0;i<n;i++) a[i]=rnd.nextInt(10);
    }

    static int[] copyArr(int a[]){
        return Arrays.copyOf(a, a.length);
    }

    // ---------------- Benchmark + Graph Generation ----------------

    static double timeSort(int original[]){
        int a[]=copyArr(original);
        long s=System.nanoTime();
        mergeSort(a,0,a.length-1);
        long e=System.nanoTime();
        return (e-s)/1e9;
    }

    public static void main(String[] args) throws Exception{
        System.setProperty("java.awt.headless","true");

        int sizes[]={100,1000,10000,100000};
        String caseNames[]={"Random","Ascending","Descending","Partially Ordered","Missing Numbers","Duplicates"};
        double results[][]=new double[6][sizes.length];

        for(int s=0;s<sizes.length;s++){
            int n=sizes[s];
            System.out.println("\n===== ARRAY SIZE = "+n+" =====");

            int r[]=new int[n],asc[]=new int[n],des[]=new int[n],par[]=new int[n],mis[]=new int[n],dup[]=new int[n];
            genRandom(r,n); genAscending(asc,n); genDescending(des,n);
            genPartial(par,n); genMissing(mis,n); genDuplicates(dup,n);
            int arrays[][]={r,asc,des,par,mis,dup};

            for(int c=0;c<6;c++){
                double t=timeSort(arrays[c]);
                results[c][s]=t;
                System.out.printf("%-20s | Size = %6d | Time = %.6f sec%n", caseNames[c], n, t);
            }
        }

        System.out.println("\n" + "=".repeat(86));
        System.out.println("MERGE SORT - EXECUTION TIME TABLE (seconds)");
        System.out.println("=".repeat(86));
        StringBuilder header=new StringBuilder(String.format("%-20s","Test Case"));
        for(int n: sizes) header.append(String.format("N=%-10d", n));
        System.out.println(header);
        System.out.println("-".repeat(86));
        for(int c=0;c<6;c++){
            StringBuilder row=new StringBuilder(String.format("%-20s", caseNames[c]));
            for(int s=0;s<sizes.length;s++) row.append(String.format("%-12.6f", results[c][s]));
            System.out.println(row);
        }
        System.out.println("=".repeat(86));

        drawChart("Merge Sort Performance", "Merge_Performance.png", sizes, caseNames, results);
    }

    // ---- Minimal pure-Java line-chart renderer (no external libraries) ----
    static void drawChart(String title, String filename, int[] sizes, String[] caseNames, double[][] results) throws Exception{
        int W=1000, H=650;
        int marginL=90, marginR=230, marginT=70, marginB=80;
        int plotW=W-marginL-marginR, plotH=H-marginT-marginB;

        BufferedImage img=new BufferedImage(W,H,BufferedImage.TYPE_INT_RGB);
        Graphics2D g=img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(Color.WHITE);
        g.fillRect(0,0,W,H);

        double maxTime=0;
        for(double[] row: results) for(double v: row) maxTime=Math.max(maxTime,v);
        if(maxTime<=0) maxTime=1;
        int maxN=sizes[sizes.length-1];

        // Gridlines + axes
        g.setColor(new Color(220,220,220));
        int gridLines=10;
        for(int i=0;i<=gridLines;i++){
            int y=marginT+plotH-i*plotH/gridLines;
            g.drawLine(marginL,y,marginL+plotW,y);
        }
        g.setColor(Color.BLACK);
        g.drawLine(marginL,marginT,marginL,marginT+plotH);
        g.drawLine(marginL,marginT+plotH,marginL+plotW,marginT+plotH);

        // X axis ticks (one per size)
        g.setFont(new Font("SansSerif",Font.PLAIN,13));
        for(int i=0;i<sizes.length;i++){
            int x=marginL + (int)((double)sizes[i]/maxN*plotW);
            g.drawLine(x,marginT+plotH,x,marginT+plotH+5);
            String lbl=String.valueOf(sizes[i]);
            g.drawString(lbl, x-g.getFontMetrics().stringWidth(lbl)/2, marginT+plotH+22);
        }
        // Y axis ticks
        for(int i=0;i<=gridLines;i++){
            double val=maxTime*i/gridLines;
            int y=marginT+plotH-i*plotH/gridLines;
            String lbl=String.format("%.3f",val);
            g.drawString(lbl, marginL-g.getFontMetrics().stringWidth(lbl)-8, y+5);
        }

        // Axis titles
        g.setFont(new Font("SansSerif",Font.BOLD,14));
        String xLabel="Input Size (N)";
        g.drawString(xLabel, marginL+plotW/2-g.getFontMetrics().stringWidth(xLabel)/2, H-25);
        Graphics2D g2=(Graphics2D)g.create();
        g2.rotate(-Math.PI/2);
        String yLabel="Time (seconds)";
        g2.drawString(yLabel, -(marginT+plotH/2+g.getFontMetrics().stringWidth(yLabel)/2), 25);
        g2.dispose();

        // Title
        g.setFont(new Font("SansSerif",Font.BOLD,20));
        g.drawString(title, W/2-g.getFontMetrics().stringWidth(title)/2, 35);

        // Series
        Color[] colors={new Color(31,119,180), new Color(255,127,14), new Color(44,160,44),
                         new Color(214,39,40), new Color(148,103,189), new Color(140,86,75)};

        for(int c=0;c<results.length;c++){
            g.setColor(colors[c % colors.length]);
            g.setStroke(new BasicStroke(2f));
            int prevX=-1, prevY=-1;
            for(int s=0;s<sizes.length;s++){
                int x=marginL + (int)((double)sizes[s]/maxN*plotW);
                int y=marginT+plotH - (int)(results[c][s]/maxTime*plotH);
                if(prevX!=-1) g.drawLine(prevX,prevY,x,y);
                g.fillOval(x-4,y-4,8,8);
                prevX=x; prevY=y;
            }
        }

        // Legend
        int lx=marginL+plotW+20, ly=marginT+10;
        g.setFont(new Font("SansSerif",Font.PLAIN,14));
        for(int c=0;c<caseNames.length;c++){
            g.setColor(colors[c % colors.length]);
            g.fillRect(lx, ly+c*26, 16, 16);
            g.setColor(Color.BLACK);
            g.drawString(caseNames[c], lx+22, ly+c*26+13);
        }

        g.dispose();
        ImageIO.write(img, "png", new File(filename));
        System.out.println("Graph saved as " + filename);
    }
}
