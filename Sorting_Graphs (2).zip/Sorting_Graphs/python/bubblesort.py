import random,time
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def genRandom(n): return [random.randint(1,100000) for _ in range(n)]
def genAscending(n): return list(range(1,n+1))
def genDescending(n): return list(range(n,0,-1))
def genPartial(n):
    a=genAscending(n)
    for _ in range(n//10+1):
        x,y=random.randrange(n),random.randrange(n)
        a[x],a[y]=a[y],a[x]
    return a
def genMissing(n):
    a=[]
    val=0
    for i in range(n):
        a.append(val)
        val+=random.randint(1,3)
    random.shuffle(a)
    return a
def genDuplicates(n): return [random.randint(1,max(1,n//10)) for _ in range(n)]

def sort(a):
    for i in range (len(a)):
        for j in range(len(a)-i-1):
            if a[j]>a[j+1]:
                a[j+1],a[j]=a[j],a[j+1]

def test(name,a):
    b=a[:]
    s=time.perf_counter()
    sort(b)
    e=time.perf_counter()
    elapsed=e-s
    print(f"{name} | Size = {len(b)} | Time = {elapsed:.6f} sec")
    return elapsed

# NOTE: Bubble Sort is O(n^2); N=100000 in pure Python would take many
# minutes per case, so the max size tested here is capped at 20000 to
# keep the benchmark practical (the C++/Java versions run the full
# N=100000 since they are compiled/JIT-ed and much faster).
sizes=[100,1000,10000,20000]
caseNames=["Random","Ascending","Descending","Partially Ordered","Missing Numbers","Duplicates"]
generators=[genRandom,genAscending,genDescending,genPartial,genMissing,genDuplicates]

results={name:[] for name in caseNames}

for n in sizes:
    print(f"\n===== ARRAY SIZE = {n} =====")
    for name, gen in zip(caseNames, generators):
        elapsed=test(name, gen(n))
        results[name].append(elapsed)

print("\n" + "="*86)
print("BUBBLE SORT - EXECUTION TIME TABLE (seconds)")
print("="*86)
header = f"{'Test Case':20s}" + "".join(f"N={n:<10d}" for n in sizes)
print(header)
print("-"*86)
for name in caseNames:
    row = f"{name:20s}" + "".join(f"{t:<12.6f}" for t in results[name])
    print(row)
print("="*86)

colors=["tab:blue","tab:orange","tab:green","tab:red","tab:purple","tab:brown"]
plt.figure(figsize=(10,6))
for name, color in zip(caseNames, colors):
    plt.plot(sizes, results[name], marker="o", color=color, label=name)
plt.xlabel("Input Size (N)")
plt.ylabel("Time (seconds)")
plt.title("Bubble Sort Performance")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("Bubble_Performance.png")
plt.show()
