import random,time
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def randomArray(n): return [random.randint(0,n*10-1) for _ in range(n)]
def ascendingArray(n): return list(range(1,n+1))
def descendingArray(n): return list(range(n,0,-1))
def partiallySortedArray(n):
    a=ascendingArray(n)
    for _ in range(n//10):
        i,j=random.randrange(n),random.randrange(n);a[i],a[j]=a[j],a[i]
    return a
def missingNumbersArray(n):
    a=[]
    val=0
    for i in range(n):
        a.append(val)
        val+=random.randint(1,3)
    random.shuffle(a)
    return a
def duplicateArray(n): return [random.randint(0,n//10) for _ in range(n)]


def bucketSort(a):
    m=max(a);b=[[] for _ in range(10)]
    for v in a:
        idx=(v*10)//(m+1)
        if idx>9:idx=9
        b[idx].append(v)
    k=0
    for x in b:
        x.sort()
        for v in x:a[k]=v;k+=1


def test(name,a):
    b=a[:]
    s=time.perf_counter_ns()
    bucketSort(b)
    e=time.perf_counter_ns()
    elapsed=(e-s)/1e9
    print(f"{name} | Size = {len(b)} | Time = {(e-s)//1000} microseconds")
    return elapsed

sizes=[100,1000,10000,100000]
caseNames=["Random","Ascending","Descending","Partially Ordered","Missing Numbers","Duplicates"]
generators=[randomArray,ascendingArray,descendingArray,partiallySortedArray,missingNumbersArray,duplicateArray]

results={name:[] for name in caseNames}

for n in sizes:
    print(f"\n===== ARRAY SIZE = {n} =====")
    for name, gen in zip(caseNames, generators):
        elapsed=test(name, gen(n))
        results[name].append(elapsed)

print("\n" + "="*86)
print("BUCKET SORT - EXECUTION TIME TABLE (seconds)")
print("="*86)
header = f"{'Test Case':20s}" + "".join(f"N={n:<10d}" for n in sizes)
print(header)
print("-"*86)
for name in caseNames:
    row = f"{name:20s}" + "".join(f"{t:<12.6f}" for t in results[name])
    print(row)
print("="*86)

colors=["tab:blue","tab:orange","tab:green","tab:red","tab:purple","tab:brown"]
plt.figure(figsize=(10,6))
for name, color in zip(caseNames, colors):
    plt.plot(sizes, results[name], marker="o", color=color, label=name)
plt.xlabel("Input Size (N)")
plt.ylabel("Time (seconds)")
plt.title("Bucket Sort Performance")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("Bucket_Performance.png")
plt.show()
