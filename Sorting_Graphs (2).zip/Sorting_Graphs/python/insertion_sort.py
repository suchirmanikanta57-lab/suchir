import random,time
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def randomArray(n): return [random.randint(0,n*10-1) for _ in range(n)]
def ascendingArray(n): return list(range(1,n+1))
def descendingArray(n): return list(range(n,0,-1))
def partiallySortedArray(n):
    a=ascendingArray(n)
    for _ in range(n//10):
        i,j=random.randrange(n),random.randrange(n);a[i],a[j]=a[j],a[i]
    return a
def missingNumbersArray(n):
    a=[]
    val=0
    for i in range(n):
        a.append(val)
        val+=random.randint(1,3)
    random.shuffle(a)
    return a
def duplicateArray(n): return [random.randint(0,n//10) for _ in range(n)]


def insertionSort(a):
    for i in range(1,len(a)):
        k=a[i];j=i-1
        while j>=0 and a[j]>k:a[j+1]=a[j];j-=1
        a[j+1]=k


def test(name,a):
    b=a[:]
    s=time.perf_counter_ns()
    insertionSort(b)
    e=time.perf_counter_ns()
    elapsed=(e-s)/1e9
    print(f"{name} | Size = {len(b)} | Time = {(e-s)//1000} microseconds")
    return elapsed

# NOTE: Insertion Sort is O(n^2); N=100000 in pure Python would take many
# minutes per case, so the max size tested here is capped at 20000 to
# keep the benchmark practical (the C++/Java versions run the full
# N=100000 since they are compiled/JIT-ed and much faster).
sizes=[100,1000,10000,20000]
caseNames=["Random","Ascending","Descending","Partially Ordered","Missing Numbers","Duplicates"]
generators=[randomArray,ascendingArray,descendingArray,partiallySortedArray,missingNumbersArray,duplicateArray]

results={name:[] for name in caseNames}

for n in sizes:
    print(f"\n===== ARRAY SIZE = {n} =====")
    for name, gen in zip(caseNames, generators):
        elapsed=test(name, gen(n))
        results[name].append(elapsed)

print("\n" + "="*86)
print("INSERTION SORT - EXECUTION TIME TABLE (seconds)")
print("="*86)
header = f"{'Test Case':20s}" + "".join(f"N={n:<10d}" for n in sizes)
print(header)
print("-"*86)
for name in caseNames:
    row = f"{name:20s}" + "".join(f"{t:<12.6f}" for t in results[name])
    print(row)
print("="*86)

colors=["tab:blue","tab:orange","tab:green","tab:red","tab:purple","tab:brown"]
plt.figure(figsize=(10,6))
for name, color in zip(caseNames, colors):
    plt.plot(sizes, results[name], marker="o", color=color, label=name)
plt.xlabel("Input Size (N)")
plt.ylabel("Time (seconds)")
plt.title("Insertion Sort Performance")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("Insertion_Performance.png")
plt.show()
