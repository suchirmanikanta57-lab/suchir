import random,time,sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.setrecursionlimit(50000)

def randomArray(n): return [random.randint(0,n*10-1) for _ in range(n)]
def ascendingArray(n): return list(range(1,n+1))
def descendingArray(n): return list(range(n,0,-1))
def partiallySortedArray(n):
    a=ascendingArray(n)
    for _ in range(n//10):
        i,j=random.randrange(n),random.randrange(n);a[i],a[j]=a[j],a[i]
    return a
def missingNumbersArray(n):
    a=[]
    val=0
    for i in range(n):
        a.append(val)
        val+=random.randint(1,3)
    random.shuffle(a)
    return a
def duplicateArray(n): return [random.randint(0,n//10) for _ in range(n)]


def partition(a,l,h):
    p=a[h];i=l-1
    for j in range(l,h):
        if a[j]<p:i+=1;a[i],a[j]=a[j],a[i]
    a[i+1],a[h]=a[h],a[i+1];return i+1
def quickSort(a,l,h):
    if l<h:
        p=partition(a,l,h);quickSort(a,l,p-1);quickSort(a,p+1,h)


def test(name,a):
    b=a[:]
    s=time.perf_counter_ns()
    quickSort(b,0,len(b)-1)
    e=time.perf_counter_ns()
    elapsed=(e-s)/1e9
    print(f"{name} | Size = {len(b)} | Time = {(e-s)//1000} microseconds")
    return elapsed

# NOTE: this quicksort always picks the LAST element as pivot (unchanged
# sorting logic), so Ascending/Descending input degrades to true O(n^2).
# N=100000 in that worst case takes many minutes in pure Python, so the
# size list below is capped at 20000 to keep the benchmark practical.
# The C++/Java versions of this same partition scheme run the full
# N=100000 comfortably since they are compiled/JIT-ed.
sizes=[100,1000,10000,20000]
caseNames=["Random","Ascending","Descending","Partially Ordered","Missing Numbers","Duplicates"]
generators=[randomArray,ascendingArray,descendingArray,partiallySortedArray,missingNumbersArray,duplicateArray]

results={name:[] for name in caseNames}

for n in sizes:
    print(f"\n===== ARRAY SIZE = {n} =====")
    for name, gen in zip(caseNames, generators):
        elapsed=test(name, gen(n))
        results[name].append(elapsed)

print("\n" + "="*86)
print("QUICK SORT - EXECUTION TIME TABLE (seconds)")
print("="*86)
header = f"{'Test Case':20s}" + "".join(f"N={n:<10d}" for n in sizes)
print(header)
print("-"*86)
for name in caseNames:
    row = f"{name:20s}" + "".join(f"{t:<12.6f}" for t in results[name])
    print(row)
print("="*86)

colors=["tab:blue","tab:orange","tab:green","tab:red","tab:purple","tab:brown"]
plt.figure(figsize=(10,6))
for name, color in zip(caseNames, colors):
    plt.plot(sizes, results[name], marker="o", color=color, label=name)
plt.xlabel("Input Size (N)")
plt.ylabel("Time (seconds)")
plt.title("Quick Sort Performance")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("Quick_Performance.png")
plt.show()
