import random
import time
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def getMax(a, n):
    mx=a[0]
    for i in range(1,n):
        if a[i]>mx:
            mx=a[i]
    return mx

def countSort(a, n, exp):
    output=[0]*n
    count=[0]*10
    for i in range(n):
        count[(a[i]//exp)%10]+=1
    for i in range(1,10):
        count[i]+=count[i-1]
    for i in range(n-1,-1,-1):
        d=(a[i]//exp)%10
        output[count[d]-1]=a[i]
        count[d]-=1
    for i in range(n):
        a[i]=output[i]

def radixSort(a, n):
    mx=getMax(a,n)
    exp=1
    while mx//exp>0:
        countSort(a,n,exp)
        exp*=10

def genRandom(n):
    a=[]
    for i in range(n):
        a.append(random.randint(0,100000))
    return a

def genAscending(n):
    a=[]
    for i in range(n):
        a.append(i)
    return a

def genDescending(n):
    a=[]
    for i in range(n):
        a.append(n-i)
    return a

def genPartial(n):
    a=genAscending(n)
    swaps=n//10+1
    for i in range(swaps):
        x=random.randint(0,n-1)
        y=random.randint(0,n-1)
        a[x],a[y]=a[y],a[x]
    return a

def genMissing(n):
    a=[]
    val=0
    for i in range(n):
        a.append(val)
        val+=random.randint(1,3)
    random.shuffle(a)
    return a

def genDuplicates(n):
    a=[]
    for i in range(n):
        a.append(random.randint(0,9))
    return a

# ---------------- Benchmark + Graph Generation ----------------
sizes=[100,1000,10000,100000]
caseNames=["Random","Ascending","Descending","Partially Ordered","Missing Numbers","Duplicates"]
generators=[genRandom,genAscending,genDescending,genPartial,genMissing,genDuplicates]

results={name:[] for name in caseNames}

for n in sizes:
    print("\n===== ARRAY SIZE =", n, "=====")
    for name, gen in zip(caseNames, generators):
        a=gen(n)
        start=time.perf_counter()
        radixSort(a,n)
        elapsed=time.perf_counter()-start
        results[name].append(elapsed)
        print(f"{name:20s} | Size = {n:6d} | Time = {elapsed:.6f} sec")

print("\n" + "="*86)
print("RADIX SORT - EXECUTION TIME TABLE (seconds)")
print("="*86)
header = f"{'Test Case':20s}" + "".join(f"N={n:<10d}" for n in sizes)
print(header)
print("-"*86)
for name in caseNames:
    row = f"{name:20s}" + "".join(f"{t:<12.6f}" for t in results[name])
    print(row)
print("="*86)

colors=["tab:blue","tab:orange","tab:green","tab:red","tab:purple","tab:brown"]
plt.figure(figsize=(10,6))
for name, color in zip(caseNames, colors):
    plt.plot(sizes, results[name], marker="o", color=color, label=name)
plt.xlabel("Input Size (N)")
plt.ylabel("Time (seconds)")
plt.title("Radix Sort Performance")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("Radix_Performance.png")
plt.show()
